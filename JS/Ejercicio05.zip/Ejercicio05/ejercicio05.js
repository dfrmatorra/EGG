/*Construir un programa que simule un menú de opciones para realizar las cuatro
operaciones aritméticas básicas (suma, resta, multiplicación y división) con dos valores
numéricos enteros. El usuario, además, debe especificar la operación con el primer
carácter de la operación que desea realizar: ‘S' o ‘s’ para la suma, ‘R’ o ‘r’ para la resta, ‘M’
o ‘m’ para la multiplicación y ‘D’ o ‘d’ para la división.*/


/*
const input = document.getElementById("input");
const guardar = document.querySelector(".btn");
const resultado = document.getElementById("resultado");

guardar.addEventListener("click", () => {
    let caracter = input.value;
    const longitud = caracter.length;
    if (caracter === "" || longitud !== 1 || !tieneLetras(caracter)) {
        alert("Ingrese un caracter");
        input.value = "";
        return;
    }
    if (!esLetraEspecial(caracter)) {
        alert("Ingrese un caracter de las opciones");
        input.value = "";
        return;
    }

});

guardar.addEventListener("click", () => {
const pedido = document.querySelector("inputGroup-sizing-lg");
pedido.textContent = "Ingrese el primer numero";
let primerNumero = parseFloat(input.value);
input.value = "";

});

guardar.addEventListener("click", () => {
pedido.textContent = "Ingrese el segundo numero";
let segundoNumero = parseFloat(input.value);
input.value = "";

switch (caracter) {
    case s:
    case S:
        resultado.textContent = `El resultado de la suma es ${parseFloat(primerNumero + segundoNumero)}`;
        break;

    case r:
    case R:
        resultado.textContent = `El resultado de la resta es ${parseFloat(primerNumero - segundoNumero)}`;
        break;

    case m:
    case M:
        resultado.textContent = `El resultado de la multiplicacion es ${parseFloat(primerNumero * segundoNumero)}`;
        break;

    case d:
    case D:
        resultado.textContent = `El resultado de la division es ${parseFloat(primerNumero / segundoNumero)}`;
        break;

    default:
        break;
}

});

function tieneLetras(caracter) {
    const letras = /[a-zA-Z]/.test(caracter);
    return letras;
}

function esLetraEspecial(caracter) {
    const regex = /[sSrRmMdD]/;
    console.log(regex.test(caracter));
    return regex.test(caracter);
}*/

const input = document.getElementById("input");
const guardar = document.querySelector(".btn");
const resultado = document.getElementById("resultado");
const pedido = document.querySelector("#pedidoDeDato"); // Definir "pedido" en un alcance más amplio
let condicion = true;
var caracter;
guardar.addEventListener("click", () => {
do{
    caracter = input.value;
    console.log(caracter);
    console.log(condicion);
    const longitud = caracter.length;
    if (caracter === "" || longitud !== 1 || !tieneLetras(caracter)) {
        alert("Ingrese un caracter");
        input.value = "";
        condicion=false;
    }
    if (!esLetraEspecial(caracter)) {
        alert("Ingrese un caracter de las opciones");
        input.value = "";
        condicion=false;
    }
    input.value = "";
    /*pedido.textContent = "Ingrese el primer numero"; // Mostrar pedido
    const primerNumero = parseFloat(input.value); // Definir primerNumero
    input.value = "";*/

}while (!condicion);
});

guardar.addEventListener("click", () =>  {
    pedido.textContent = "Ingrese el primer numero"; // Mostrar pedido
    const primerNumero = parseFloat(input.value); // Definir primerNumero
    input.value = "";

});

guardar.addEventListener("click", () => {
    pedido.textContent = "Ingrese el segundo numero"; // --TODO--- cambiar el textcontent por otro metodo
    const segundoNumero = parseFloat(input.value); // Definir segundoNumero
    input.value = "";
});

guardar.addEventListener("click", () => {
    switch (caracter) {
        case 's':
        case 'S':
            resultado.textContent = `El resultado de la suma es ${parseFloat(primerNumero + segundoNumero)}`;
            break;
        case 'r':
        case 'R':
            resultado.textContent = `El resultado de la resta es ${parseFloat(primerNumero - segundoNumero)}`;
            break;
        case 'm':
        case 'M':
            resultado.textContent = `El resultado de la multiplicacion es ${parseFloat(primerNumero * segundoNumero)}`;
            break;
        case 'd':
        case 'D':
            resultado.textContent = `El resultado de la division es ${parseFloat(primerNumero / segundoNumero)}`;
            break;
        default:
            break;
    }
});

function tieneLetras(caracter) {
    const letras = /[a-zA-Z]/.test(caracter);
    return letras;
}

function esLetraEspecial(caracter) {
    const regex = /[sSrRmMdD]/;
    console.log(regex.test(caracter));
    return regex.test(caracter);
}