package com.gaucho.estancias.excepciones;

public class MiException extends Exception{

    public MiException(String message) {
        super(message);
    }
}
