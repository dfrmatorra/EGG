package libreria;

import java.util.Scanner;
import libreria.servicios.AutorServicios;
import libreria.servicios.EditorialServicio;

/**
 *
 * @author Cristian
 */
public class Libreria {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        AutorServicios as = new AutorServicios();
        EditorialServicio es = new EditorialServicio();

        Scanner leer = new Scanner(System.in);
        int menu = 0;
        do {
            System.out.println("=========================");
            System.out.println("LIBRERÍA - MENU PRINCIPAL");
            System.out.println("-------------------------");
            System.out.println("1. AUTORES");
            System.out.println("2. EDITORIALES");
            System.out.println("3. LIBROS");
            System.out.println("4. Salir");
            System.out.println("=========================");
            menu = leer.nextInt();
            switch (menu) {
                case 1:
                    System.out.println("*--------------------------*");
                    as.menu();
                    break;
                case 2:
                    System.out.println("*--------------------------*");
                    es.menu();
                    break;
                case 3:
                    System.out.println("*--------------------------*");

                    break;                
                case 4:
                    System.out.println("*--------------------------*");
                    System.out.println("    PROGRAMA TERMINADO");
                    break;
                default:
                    System.out.println("*--------------------------*");
                    System.out.println("       OPCIÓN NO VÁLIDA");

            }
            System.out.println("*--------------------------*");
        } while (menu != 4);

    }

}
