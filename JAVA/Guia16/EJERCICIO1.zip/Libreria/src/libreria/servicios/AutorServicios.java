package libreria.servicios;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import libreria.entidades.Autor;

/**
 *
 * @author Cristian
 */
public class AutorServicios extends Servicios {

    private Scanner leerN = new Scanner(System.in);
    private Scanner leerT = new Scanner(System.in);
    private List<Autor> autores = new ArrayList();
    private Autor autor = new Autor();

//CREAR AUTORES
//Creamos un objeto Autor y le asignamos el nombre
    public void crearAutor() {
        Scanner leer = new Scanner(System.in);
        String nombre;
        System.out.println("Ingresar el nombre del autor");
        nombre = leer.nextLine();

        Autor autor1 = new Autor();
        autor1.setNombre(nombre);
        //autor1.setAlta(Boolean.TRUE);

        //Iniciamos una transacción con el método getTransaction().begin()
        em.getTransaction().begin();

        //Persistimos el objeto
        em.persist(autor1);

        /* Terminamos la transacción con el método commit. Commit en programación
    significa confirmar un conjunto de cambios, en este caso persistir el objeto */
        em.getTransaction().commit();

        System.out.println("<<<AUTOR CREADO>>>");

    }

//LISTAR AUTORES
    //Usamos el método createQuery y le ponesmos la query de JPQL
    public void listarAutores() {
        autores = em.createQuery("select a from Autor a").getResultList();

        System.out.println("AUTORES");
        System.out.println("=======");
        for (Autor autorAux : autores) {
            System.out.println(autorAux);
        }
    }

//MODIFICAR AUTOR
    //Usamos el método find() primero para identificar al autor
    //y luego el em.merge() para modificarlo.
    public void modificarAutor() {
        String nombre;
        int id;
        //Primero listamos los autores actuales
        listarAutores();

//Pedimos al usuario que seleccione el id del autor a modificar
        System.out.println("---------------------------");
        System.out.println("Revise la lista de autores. \nIngrese el 'Id' del autor a modificar");
        System.out.println("---------------------------");
        id = leerN.nextInt();

//buscamos el Autor con el método find()        
        autor = em.find(Autor.class, id);

//Pedimos al usuario que ingrese el nuevo nombre
        System.out.println("Ingresar el nuevo nombre del autor");
        nombre = leerT.nextLine();

//Asignamos el nombre al autor
        autor.setNombre(nombre);

//Actualizamos el autor dentro de la base de datos.
        em.getTransaction().begin();
        em.merge(autor);
        em.getTransaction().commit();
    }

//ELIMINAR AUTOR
    //Usamos el método find() primero para identificar al autor
    //Usamos el método em.remove() 
    public void eliminarAutor() {
        int id;
        //Listamos los autores actuales
        listarAutores();

        //Pedimos al usuario que seleccione el id del autor a modificar
        System.out.println("---------------------------");
        System.out.println("Revise la lista de autores. \nIngrese el 'Id' del autor a ELIMINAR");
        System.out.println("---------------------------");
        id = leerN.nextInt();

        //Buscamos el Autor a eliminar usando el id
        autor = em.find(Autor.class, id);

        //Eliminamos al autor de la tabla
        em.getTransaction().begin();
        em.remove(autor);
        em.getTransaction().commit();

    }

    //MENU - AUTORES
    public void menu() {
        int menu = 0;
        do {
            System.out.println("AUTORES - MENU");
            System.out.println("--------------");
            System.out.println("1. Crear Autor");
            System.out.println("2. Listar Autores");
            System.out.println("3. Modificar Autor");
            System.out.println("4. Eliminar Autor");
            System.out.println("5. VOLVER al menu anterior");
            menu = leerN.nextInt();

            switch (menu) {
                case 1:
                    System.out.println("*--------------------------*");
                    crearAutor();
                    break;
                case 2:
                    System.out.println("*--------------------------*");
                    listarAutores();
                    break;
                case 3:
                    System.out.println("*--------------------------*");
                    modificarAutor();
                    break;
                case 4:
                    System.out.println("*--------------------------*");
                    eliminarAutor();
                    break;
                default:
                    System.out.println("*--------------------------*");
                    System.out.println("       OPCIÓN NO VÁLIDA");
            }
            System.out.println("*--------------------------*");
        } while (menu != 5);
    }
}
