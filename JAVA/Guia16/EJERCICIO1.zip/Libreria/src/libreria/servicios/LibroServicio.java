package libreria.servicios;

/**
 *
 * @author Cristian
 */
public class LibroServicio {
    
}
