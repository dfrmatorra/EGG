package libreria.servicios;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import libreria.entidades.Editorial;

/**
 *
 * @author Cristian
 */
public class EditorialServicio extends Servicios {

    private Scanner leerN = new Scanner(System.in);
    private Scanner leerT = new Scanner(System.in);
    private List<Editorial> editoriales = new ArrayList();
    private Editorial editorial = new Editorial();

    //CREAR EDITORIALES
    //Creamos un objeto Editorial y le asignamos 
    public void crearEditorial() {
        Scanner leer = new Scanner(System.in);
        String nombre;
        System.out.println("Ingresar el nombre de la Editorial");
        nombre = leer.nextLine();

        editorial.setNombre(nombre);

        //Iniciamos una transacción con el método getTransaccion()
        em.getTransaction().begin();

        //Persistimos el objeto
        em.persist(editorial);

        //Terminamos y confirmamos 
        em.getTransaction().commit();

        System.out.println("<<<EDITORIAL CREADA>>>");

    }

    //LISTAR EDITORIALES
    //Usamos el método createQuery y le ponemos la query de JPQL
    public void listarEditoriales() {
        editoriales = em.createQuery("select e from Editorial e").getResultList();

        System.out.println("EDITORIALES");
        System.out.println("===========");
        for (Editorial editorialAux : editoriales) {
            System.out.println(editorialAux);
        }
    }

    //MODIFICAR EDITORIAL
    //Usamos el método find() primero para identificar la Editorial
    //y luego el em.merge() para modificarla.
    public void modificarEditorial() {
        String nombre;
        int id;

        //Primero listamos las editoriales existentes
        listarEditoriales();

        //Pedimos al usuario que seleccione el id de la editorial a modificar
        System.out.println("------------------");
        System.out.println("Revise la lista de Editoriales.\nIngrese el"
                + " 'Id' de la Editorial a modificar");
        System.out.println("------------------");
        id = leerN.nextInt();

        //Buscamos la Editorial con el método find()
        editorial = em.find(Editorial.class, id);

        //Pedimos al usuario que ingrese el nuevo nombre
        System.out.println("Ingresar el nuevo nombre de la Editorial");
        nombre = leerT.nextLine();

        //Asignamos el nombre a la editorial
        editorial.setNombre(nombre);

        //Actualizamos los datos en la base de datos
        em.getTransaction().begin();
        em.merge(editorial);
        em.getTransaction().commit();
    }

    //ELIMINAR EDITORIAL
    //Usamos el método find() primero para identificar la editorial
    //Usamos el método em.remove() y eliminamos
    public void eliminarEditorial() {
        int id;
        //Listamos Editoriales actuales
        listarEditoriales();

        //Peidmos al usuario que seleccione el id de la editorial a borrar
        System.out.println("-------------------------------");
        System.out.println("Revise la lista de Editoriales "
                + "\n Ingrese el 'Id' de la Editorial a ELIMINAR");
        System.out.println("-------------------------------");
        id = leerN.nextInt();
        
        //Buscamos la Editorial a eliminar usando el Id
        editorial=em.find(Editorial.class,id);
        
        //Eliminamos la Editorial
        em.getTransaction().begin();
        em.remove(editorial);
        em.getTransaction().commit();       
    }

    //MENU - AUTORES
    public void menu() {
        int menu = 0;
        do {
            System.out.println("EDITORIALES - MENU");
            System.out.println("------------------");
            System.out.println("1. Crear Editorial");
            System.out.println("2. Listar Editoriales");
            System.out.println("3. Modificar Editorial");
            System.out.println("4. Eliminar Editorial");
            System.out.println("5. VOLVER al menu anterior");
            menu = leerN.nextInt();

            switch (menu) {
                case 1:
                    System.out.println("*--------------------------*");
                    crearEditorial();
                    break;
                case 2:
                    System.out.println("*--------------------------*");
                    listarEditoriales();
                    break;
                case 3:
                    System.out.println("*--------------------------*");
                    modificarEditorial();
                    break;
                case 4:
                    System.out.println("*--------------------------*");
                    //eliminarEditorial();
                    break;
                default:
                    System.out.println("*--------------------------*");
                    System.out.println("       OPCIÓN NO VÁLIDA");
            }
            System.out.println("*--------------------------*");
        } while (menu != 5);
    }

}
