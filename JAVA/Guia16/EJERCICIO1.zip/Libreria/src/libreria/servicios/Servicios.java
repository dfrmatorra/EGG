/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libreria.servicios;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

/**
 *
 * @author Cristian
 */
public class Servicios {
    
    //Creamos un Entity Manager
        EntityManager em=Persistence.createEntityManagerFactory("LibreriaPU").createEntityManager();
    
}
