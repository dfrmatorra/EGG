package Enum;

/**
 *
 * @author CASA
 */
public enum Amarre {
    A, B, C, D, E;
    
}
